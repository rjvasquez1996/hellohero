import json
import xlsxwriter
import boto3
def lambda_handler(event,context):
	s3 = boto3.resource('s3')
	BUCKET="hellohero"
	s3_url="https://hellohero.s3.amazonaws.com"
	PATH=""
	try:
		data = event	
		if(len(data)==0):
			return {"status":False,"message":"debe ingresar datos","data":""}
		with open("/tmp/compras.xlsx", "w+") as file:
			workbook = xlsxwriter.Workbook("/tmp/compras.xlsx")
			worksheet = workbook.add_worksheet()
			headers=[]
			for col_num,key in enumerate(data[0]):
				headers.append(key)
				worksheet.write(0,col_num,key)
			for i,json in enumerate(data):
				for j,key in enumerate(json):
					worksheet.write(i+1,j,data[i][key])
			workbook.close()
		PATH=PATH+"compras.xlsx"
		s3.meta.client.upload_file("/tmp/compras.xlsx",BUCKET,PATH)
	except:
		return {"status":False,"message":"error generando y subiendo el excel a s3","data":""}	
	return {"status":True,"message":"Excel creado correctamente","data":s3_url+"/compras.xlsx"}